---
name: Bug report
about: Create a report to help us improve
title: ""
labels: bug
assignees: ""
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:

1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**Screenshots**
If applicable, add screenshots to help explain your problem.

**System (please complete the following information):**

- OS: [e.g. MacOS]
- Zotero version [e.g. 6 or 7 or 8]
- Plugin version [e.g. 22]

**Additional context**
Add any other context about the problem here.
