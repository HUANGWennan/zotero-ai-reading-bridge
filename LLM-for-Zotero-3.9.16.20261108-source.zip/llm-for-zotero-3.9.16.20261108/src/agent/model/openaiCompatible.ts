import { appLogger } from "../../core/logging";
import { usesMaxCompletionTokens } from "../../utils/apiHelpers";
import {
  buildReasoningPayload,
  buildPromptCachePayloadHints,
  normalizeProviderCompletion,
  postWithReasoningFallback,
  resolveRequestAuthState,
} from "../../utils/llmClient";
import { normalizeTemperature } from "../../utils/normalization";
import { detectProviderPreset } from "../../utils/providerPresets";
import { resolveProviderTransportEndpoint } from "../../utils/providerTransport";
import { extractContextCacheUsage } from "../../contextCache/manager";
import type {
  AgentModelCapabilities,
  AgentModelMessage,
  AgentModelStep,
  AgentRuntimeRequest,
  AgentToolCall,
  ToolSpec,
} from "../types";
import type { AgentModelAdapter, AgentStepParams } from "./adapter";
import { buildAgentModelCapabilities } from "./contentCapabilities";
import { resolveRequestContentInputs } from "./messageBuilder";
import {
  buildOpenAIFunctionTools,
  createFallbackToolCallId,
  parseToolCallArguments,
} from "./shared";
import { resolveContentParts } from "./adapterUtils";
import { resolveAgentTransmittedOutputPolicy } from "./limits";
import { estimateWirePayloadTokens } from "../../utils/modelInputCap";
import {
  buildAgentRecoveryInstruction,
  resolveAgentRecoverableCompletion,
} from "./completion";

type ChatCompletionChoice = {
  finish_reason?: string | null;
  message?: {
    content?: string | null;
    reasoning_content?: string | null;
    reasoning?: string | null;
    thinking?: string | null;
    tool_calls?: Array<{
      id?: string;
      function?: {
        name?: string;
        arguments?: string;
      };
    }>;
  };
};

type OpenAIChatRequestMessage = {
  role: AgentModelMessage["role"];
  content: string | unknown[];
  reasoning_content?: string;
  tool_call_id?: string;
  name?: string;
  tool_calls?: Array<{
    id: string;
    type: "function";
    function: { name: string; arguments: string };
  }>;
};

function isDeepseekChatModel(modelName?: string): boolean {
  const normalized = (modelName || "").trim().toLowerCase();
  if (!normalized) return false;
  const tail = normalized.split("/").pop() || "";
  const candidates =
    tail && tail !== normalized ? [normalized, tail] : [normalized];
  return candidates.some((candidate) => /^deepseek(?:$|[-.])/.test(candidate));
}

function buildReasoningContentForContinuation(
  modelName: string | undefined,
  reasoningText: string,
  reasoningContentText = reasoningText,
): { reasoning_content?: string } {
  const textToEcho = isDeepseekChatModel(modelName)
    ? reasoningText
    : reasoningContentText;
  const trimmed = textToEcho.trim();
  return trimmed ? { reasoning_content: trimmed } : {};
}

function isToolCapableApiBase(request: AgentRuntimeRequest): boolean {
  const apiBase = (request.apiBase || "").trim();
  if (!apiBase) return false;
  if (request.authMode === "codex_auth") return false;
  return true;
}

const KIMI_JSON_SCHEMA_KEYWORDS = new Set([
  "$id",
  "$defs",
  "$ref",
  "type",
  "properties",
  "required",
  "additionalProperties",
  "anyOf",
  "items",
  "enum",
  "maximum",
  "minimum",
  "maxLength",
  "minLength",
  "maxItems",
  "minItems",
  "title",
  "description",
  "default",
]);

const KIMI_JSON_TYPES = [
  "null",
  "boolean",
  "object",
  "array",
  "number",
  "integer",
  "string",
] as const;

function cloneJsonValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map((entry) => cloneJsonValue(entry));
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(
    Object.entries(value as Record<string, unknown>).map(([key, entry]) => [
      key,
      cloneJsonValue(entry),
    ]),
  );
}

function mergeKimiAnyOfBranch(
  constraints: Record<string, unknown>,
  variant: unknown,
): unknown {
  if (!variant || typeof variant !== "object" || Array.isArray(variant)) {
    return variant;
  }
  const branch = variant as Record<string, unknown>;
  const merged = {
    ...constraints,
    ...branch,
  };
  if (
    constraints.properties &&
    typeof constraints.properties === "object" &&
    !Array.isArray(constraints.properties) &&
    branch.properties &&
    typeof branch.properties === "object" &&
    !Array.isArray(branch.properties)
  ) {
    merged.properties = {
      ...(constraints.properties as Record<string, unknown>),
      ...(branch.properties as Record<string, unknown>),
    };
  }
  if (Array.isArray(constraints.required) && Array.isArray(branch.required)) {
    merged.required = Array.from(
      new Set([...constraints.required, ...branch.required]),
    );
  }
  return merged;
}

function inferKimiJsonSchemaType(
  schema: Record<string, unknown>,
): (typeof KIMI_JSON_TYPES)[number] | undefined {
  if (
    schema.properties !== undefined ||
    schema.required !== undefined ||
    schema.additionalProperties !== undefined
  ) {
    return "object";
  }
  if (
    schema.items !== undefined ||
    schema.minItems !== undefined ||
    schema.maxItems !== undefined
  ) {
    return "array";
  }
  if (schema.minLength !== undefined || schema.maxLength !== undefined) {
    return "string";
  }
  if (schema.minimum !== undefined || schema.maximum !== undefined) {
    return "number";
  }
  if (Array.isArray(schema.enum) && schema.enum.length) {
    const types = new Set(
      schema.enum.map((value) =>
        value === null
          ? "null"
          : typeof value === "number"
            ? "number"
            : typeof value,
      ),
    );
    const [type] = types;
    if (
      types.size === 1 &&
      KIMI_JSON_TYPES.includes(type as (typeof KIMI_JSON_TYPES)[number])
    ) {
      return type as (typeof KIMI_JSON_TYPES)[number];
    }
  }
  return undefined;
}

function normalizeKimiJsonSchema(schema: unknown, isRoot = true): unknown {
  if (!schema || typeof schema !== "object" || Array.isArray(schema)) {
    return cloneJsonValue(schema);
  }

  const normalized: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(
    schema as Record<string, unknown>,
  )) {
    if (!KIMI_JSON_SCHEMA_KEYWORDS.has(key)) continue;
    if ((key === "$id" || key === "$defs") && !isRoot) continue;
    if (key === "properties" || key === "$defs") {
      if (!value || typeof value !== "object" || Array.isArray(value)) {
        normalized[key] = cloneJsonValue(value);
        continue;
      }
      normalized[key] = Object.fromEntries(
        Object.entries(value as Record<string, unknown>).map(
          ([name, childSchema]) => [
            name,
            normalizeKimiJsonSchema(childSchema, false),
          ],
        ),
      );
      continue;
    }
    if (key === "anyOf" && Array.isArray(value)) {
      normalized.anyOf = value.map((variant) =>
        normalizeKimiJsonSchema(variant, false),
      );
      continue;
    }
    if (
      key === "items" ||
      (key === "additionalProperties" &&
        value !== null &&
        typeof value === "object")
    ) {
      normalized[key] = normalizeKimiJsonSchema(value, false);
      continue;
    }
    normalized[key] = cloneJsonValue(value);
  }

  if (
    !Array.isArray(normalized.anyOf) &&
    normalized.type === undefined &&
    normalized.$ref === undefined
  ) {
    const inferredType = inferKimiJsonSchemaType(normalized);
    if (inferredType) return { type: inferredType, ...normalized };
    const { description, title } = normalized;
    return {
      ...(description !== undefined ? { description } : {}),
      ...(title !== undefined ? { title } : {}),
      anyOf: KIMI_JSON_TYPES.map((type) => ({ type })),
    };
  }

  if (!Array.isArray(normalized.anyOf)) return normalized;

  const outer: Record<string, unknown> = {};
  const constraints: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(normalized)) {
    if (key === "anyOf") continue;
    if (
      key === "description" ||
      key === "title" ||
      key === "$id" ||
      key === "$defs"
    ) {
      outer[key] = value;
    } else {
      constraints[key] = value;
    }
  }

  return {
    ...outer,
    anyOf: normalized.anyOf.map((variant) =>
      normalizeKimiJsonSchema(
        mergeKimiAnyOfBranch(constraints, variant),
        false,
      ),
    ),
  };
}

function buildProviderFunctionTools(
  request: AgentRuntimeRequest,
  tools: ToolSpec[],
) {
  const serializedTools = buildOpenAIFunctionTools(tools);
  if (detectProviderPreset(request.apiBase || "") !== "kimi") {
    return serializedTools;
  }
  return serializedTools.map((tool) => ({
    ...tool,
    function: {
      ...tool.function,
      parameters: normalizeKimiJsonSchema(tool.function.parameters) as object,
    },
  }));
}

function hasPdfFileRef(message: AgentModelMessage): boolean {
  if (typeof message.content === "string") return false;
  return message.content.some(
    (part) =>
      part.type === "file_ref" &&
      part.file_ref.mimeType.trim().toLowerCase() === "application/pdf",
  );
}

async function buildMessagesPayload(
  messages: AgentModelMessage[],
): Promise<OpenAIChatRequestMessage[]> {
  const result: OpenAIChatRequestMessage[] = [];
  for (const message of messages) {
    if (message.role === "tool") {
      result.push({
        role: "tool",
        content: message.content,
        tool_call_id: message.tool_call_id,
        name: message.name,
      });
      continue;
    }
    let content: string | unknown[];
    if (typeof message.content === "string") {
      content = message.content;
    } else {
      if (hasPdfFileRef(message)) {
        throw new Error(
          "OpenAI-compatible chat cannot send unresolved PDF file_ref attachments. Render the PDF to page images or use a native PDF provider.",
        );
      }
      const resolved = await resolveContentParts(message);
      const parts: unknown[] = [];
      for (const rp of resolved) {
        switch (rp.type) {
          case "text":
            parts.push({ type: "text", text: rp.text });
            break;
          case "image":
            if (rp.mimeType.trim().toLowerCase() === "application/pdf") {
              throw new Error(
                "OpenAI-compatible chat cannot send PDF content as image_url.",
              );
            }
            parts.push({
              type: "image_url",
              image_url: {
                url: `data:${rp.mimeType};base64,${rp.base64}`,
                ...(rp.detail ? { detail: rp.detail } : {}),
              },
            });
            break;
          case "pdf":
            throw new Error(
              "OpenAI-compatible chat cannot send PDF content as image_url.",
            );
          // file_placeholder: silently dropped (no provider support)
        }
      }
      content = parts;
    }
    result.push({
      role: message.role,
      content,
      ...(message.role === "assistant" &&
      Array.isArray(message.tool_calls) &&
      message.tool_calls.length
        ? {
            tool_calls: message.tool_calls.map((call: AgentToolCall) => ({
              id: call.id,
              type: "function",
              function: {
                name: call.name,
                arguments: JSON.stringify(call.arguments ?? {}),
              },
            })),
          }
        : {}),
    });
  }
  return result;
}

function buildNativeAssistantMessage(params: {
  modelName?: string;
  text: string;
  reasoningText: string;
  reasoningContentText: string;
  toolCalls: AgentToolCall[];
}): OpenAIChatRequestMessage {
  return {
    role: "assistant",
    content: params.text,
    ...buildReasoningContentForContinuation(
      params.modelName,
      params.reasoningText,
      params.reasoningContentText,
    ),
    ...(params.toolCalls.length
      ? {
          tool_calls: params.toolCalls.map((call) => ({
            id: call.id,
            type: "function" as const,
            function: {
              name: call.name,
              arguments: JSON.stringify(call.arguments ?? {}),
            },
          })),
        }
      : {}),
  };
}

function normalizeToolCalls(
  toolCalls:
    | Array<{
        id?: string;
        function?: {
          name?: string;
          arguments?: string;
        };
      }>
    | undefined,
): AgentToolCall[] {
  if (!Array.isArray(toolCalls)) return [];
  return toolCalls
    .map((call, index) => {
      const name = call?.function?.name?.trim();
      if (!name) return null;
      return {
        id: call?.id?.trim() || createFallbackToolCallId("tool", index),
        name,
        arguments: parseToolCallArguments(call?.function?.arguments),
      };
    })
    .filter((call): call is AgentToolCall => Boolean(call));
}

type StreamedToolCallAccumulator = {
  id: string;
  name: string;
  argumentChunks: string[];
};

async function parseOpenAIChatCompletionStream(
  body: ReadableStream<Uint8Array>,
  onTextDelta?: (delta: string) => void | Promise<void>,
  onReasoning?: (event: {
    summary?: string;
    details?: string;
  }) => void | Promise<void>,
  onUsage?: AgentStepParams["onUsage"],
): Promise<{
  text: string;
  toolCalls: AgentToolCall[];
  reasoningText: string;
  reasoningContentText: string;
  finishReason?: string;
}> {
  const reader = body.getReader() as ReadableStreamDefaultReader<Uint8Array>;
  const decoder = new TextDecoder("utf-8");
  let buffer = "";
  let fullText = "";
  let reasoningText = "";
  let reasoningContentText = "";
  let finishReason: string | undefined;
  let receivedTerminal = false;
  const toolCallMap = new Map<number, StreamedToolCallAccumulator>();

  try {
    while (!receivedTerminal) {
      const { value, done } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("data:")) continue;
        const data = trimmed.slice(5).trim();
        if (data === "[DONE]") {
          receivedTerminal = true;
          break;
        }
        if (!data) continue;

        try {
          const parsed = JSON.parse(data);
          if (parsed?.usage && onUsage) {
            const promptTokens =
              typeof parsed.usage.prompt_tokens === "number"
                ? parsed.usage.prompt_tokens
                : 0;
            const completionTokens =
              typeof parsed.usage.completion_tokens === "number"
                ? parsed.usage.completion_tokens
                : 0;
            const totalTokens =
              typeof parsed.usage.total_tokens === "number"
                ? parsed.usage.total_tokens
                : promptTokens + completionTokens;
            if (totalTokens > 0) {
              await onUsage({
                promptTokens,
                completionTokens,
                totalTokens,
                ...extractContextCacheUsage(parsed.usage),
                contextTokens: promptTokens,
                contextWindowIsAuthoritative: promptTokens > 0,
              });
            }
          }
          const choice = parsed?.choices?.[0];
          if (typeof choice?.finish_reason === "string") {
            finishReason = choice.finish_reason;
          }
          const delta = choice?.delta;
          if (!delta) continue;

          // Text content
          const textDelta =
            typeof delta.content === "string" ? delta.content : "";
          if (textDelta) {
            fullText += textDelta;
            if (onTextDelta) await onTextDelta(textDelta);
          }

          // Reasoning (various provider field names)
          const reasoningContentDelta =
            typeof delta.reasoning_content === "string"
              ? delta.reasoning_content
              : "";
          const rDelta =
            reasoningContentDelta ||
            delta.reasoning ||
            delta.thinking ||
            delta.thought ||
            "";
          if (reasoningContentDelta) {
            reasoningContentText += reasoningContentDelta;
          }
          if (typeof rDelta === "string" && rDelta) {
            reasoningText += rDelta;
            if (onReasoning) await onReasoning({ details: rDelta });
          }

          // Streamed tool calls
          if (Array.isArray(delta.tool_calls)) {
            for (const tc of delta.tool_calls) {
              const idx =
                typeof tc.index === "number" ? tc.index : toolCallMap.size;
              if (!toolCallMap.has(idx)) {
                toolCallMap.set(idx, {
                  id: tc.id?.trim() || createFallbackToolCallId("tool", idx),
                  name: tc.function?.name?.trim() || "",
                  argumentChunks: [],
                });
              }
              const entry = toolCallMap.get(idx)!;
              if (tc.id?.trim()) entry.id = tc.id.trim();
              if (tc.function?.name?.trim())
                entry.name = tc.function.name.trim();
              if (typeof tc.function?.arguments === "string") {
                entry.argumentChunks.push(tc.function.arguments);
              }
            }
          }
        } catch (err) {
          appLogger.warn("LLM: Malformed SSE line in OpenAI stream", err);
        }
      }
    }
  } finally {
    if (receivedTerminal) {
      // The response is complete; transport cleanup must not delay its result.
      void reader.cancel().catch(() => undefined);
    }
    reader.releaseLock();
  }

  const toolCalls: AgentToolCall[] = [];
  for (const [, entry] of toolCallMap) {
    if (!entry.name) continue;
    toolCalls.push({
      id: entry.id,
      name: entry.name,
      arguments: parseToolCallArguments(entry.argumentChunks.join("")),
    });
  }

  return {
    text: fullText,
    toolCalls,
    reasoningText,
    reasoningContentText,
    finishReason,
  };
}

function isStreamingResponse(response: Response): boolean {
  const ct = (response.headers.get("content-type") || "").toLowerCase();
  return ct.includes("text/event-stream") || ct.includes("octet-stream");
}

export class OpenAIChatCompatAgentAdapter implements AgentModelAdapter {
  private conversationMessages: OpenAIChatRequestMessage[] | null = null;

  getCapabilities(request: AgentRuntimeRequest): AgentModelCapabilities {
    return buildAgentModelCapabilities({
      streaming: true,
      toolCalls: isToolCapableApiBase(request),
      contentInputs: resolveRequestContentInputs(request),
      fileInputs: false,
      reasoning: true,
    });
  }

  supportsTools(request: AgentRuntimeRequest): boolean {
    return this.getCapabilities(request).toolCalls;
  }

  resetState(): void {
    this.conversationMessages = null;
  }

  async runStep(params: AgentStepParams): Promise<AgentModelStep> {
    const request = params.request;
    const auth = await resolveRequestAuthState({
      authMode: request.authMode || "api_key",
      apiKey: request.apiKey || "",
      signal: params.signal,
    });
    const url = resolveProviderTransportEndpoint({
      protocol: "openai_chat_compat",
      apiBase: request.apiBase || "",
      authMode: request.authMode,
    });
    const resolvedMessages = this.conversationMessages
      ? [
          ...this.conversationMessages,
          ...(await buildMessagesPayload(params.continuationMessages || [])),
        ]
      : await buildMessagesPayload(params.messages);
    const outputPolicy = resolveAgentTransmittedOutputPolicy(
      request,
      "openai_chat_compat",
      estimateWirePayloadTokens({
        messages: resolvedMessages,
        tools: params.tools,
      }),
    );
    const response = await postWithReasoningFallback({
      url,
      scope: { conversationKey: request.conversationKey },
      auth,
      modelName: request.model,
      initialReasoning: request.reasoning,
      buildPayload: (reasoningOverride) => {
        const reasoningPayload = buildReasoningPayload(
          reasoningOverride,
          false,
          request.model,
          request.apiBase,
          "openai_chat_compat",
          { profileOverride: request.advanced?.profileOverride },
        );
        return {
          model: request.model,
          messages: resolvedMessages,
          ...buildPromptCachePayloadHints(request.contextCache),
          tools: buildProviderFunctionTools(request, params.tools),
          tool_choice: params.toolChoice === "none" ? "none" : "auto",
          stream: true,
          stream_options: { include_usage: true },
          ...(outputPolicy.mode === "numeric"
            ? usesMaxCompletionTokens(request.model || "")
              ? { max_completion_tokens: outputPolicy.tokens }
              : { max_tokens: outputPolicy.tokens }
            : {}),
          ...reasoningPayload.extra,
          ...(reasoningPayload.omitTemperature
            ? {}
            : {
                temperature: normalizeTemperature(
                  request.advanced?.temperature,
                ),
              }),
        };
      },
      signal: params.signal,
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(
        `${response.status} ${response.statusText} - ${errorText}`,
      );
    }

    // Stream path: parse SSE and deliver text deltas progressively
    if (response.body && isStreamingResponse(response)) {
      let result: Awaited<ReturnType<typeof parseOpenAIChatCompletionStream>>;
      try {
        result = await parseOpenAIChatCompletionStream(
          response.body,
          params.onTextDelta,
          params.onReasoning,
          params.onUsage,
        );
      } catch (error) {
        // This adapter executes no tools while parsing. A broken stream can
        // safely retry the unfinished model step, never its partial calls.
        if (
          params.signal?.aborted ||
          !/^(?:Error: )?Error in input stream$/.test(String(error))
        )
          throw error;
        const assistantMessage = { role: "assistant" as const, content: "" };
        this.conversationMessages = [...resolvedMessages, assistantMessage];
        return {
          kind: "incomplete",
          reason: "stream_interrupted",
          text: "",
          recoveryInstruction: buildAgentRecoveryInstruction(
            "stream_interrupted",
            "tool call",
          ),
          assistantMessage,
        };
      }
      const completion = normalizeProviderCompletion(result.finishReason);
      const recoveryReason = resolveAgentRecoverableCompletion(completion);
      this.conversationMessages = [
        ...resolvedMessages,
        recoveryReason
          ? { role: "assistant", content: result.text }
          : buildNativeAssistantMessage({
              modelName: request.model,
              text: result.text,
              reasoningText: result.reasoningText,
              reasoningContentText: result.reasoningContentText,
              toolCalls: result.toolCalls,
            }),
      ];
      if (recoveryReason) {
        return {
          kind: "incomplete",
          reason: recoveryReason,
          providerReason: completion.providerReason,
          text: result.text,
          recoveryInstruction: buildAgentRecoveryInstruction(
            recoveryReason,
            "tool call",
          ),
          assistantMessage: {
            role: "assistant",
            content: result.text,
          },
        };
      }
      if (result.toolCalls.length) {
        return {
          kind: "tool_calls",
          calls: result.toolCalls,
          assistantMessage: {
            role: "assistant",
            content: result.text,
            tool_calls: result.toolCalls,
          },
        };
      }
      return {
        kind: "final",
        text: result.text,
        assistantMessage: {
          role: "assistant",
          content: result.text,
        },
      };
    }

    // Fallback: non-streaming JSON response
    const data = (await response.json()) as {
      choices?: ChatCompletionChoice[];
      usage?: {
        prompt_tokens?: number;
        completion_tokens?: number;
        total_tokens?: number;
        prompt_tokens_details?: { cached_tokens?: number };
        prompt_cache_hit_tokens?: number;
        prompt_cache_miss_tokens?: number;
        cached_tokens?: number;
      };
    };
    if (data.usage && params.onUsage) {
      const promptTokens = data.usage.prompt_tokens ?? 0;
      const completionTokens = data.usage.completion_tokens ?? 0;
      const totalTokens =
        data.usage.total_tokens ?? promptTokens + completionTokens;
      if (totalTokens > 0) {
        await params.onUsage({
          promptTokens,
          completionTokens,
          totalTokens,
          ...extractContextCacheUsage(data.usage),
          contextTokens: promptTokens,
          contextWindowIsAuthoritative: promptTokens > 0,
        });
      }
    }
    const message = data.choices?.[0]?.message;
    const finishReason = data.choices?.[0]?.finish_reason;
    const reasoningContentText =
      typeof message?.reasoning_content === "string"
        ? message.reasoning_content
        : "";
    const reasoningText =
      reasoningContentText || message?.reasoning || message?.thinking || "";
    if (reasoningText && params.onReasoning) {
      await params.onReasoning({ details: reasoningText });
    }
    const toolCalls = normalizeToolCalls(message?.tool_calls);
    const text = typeof message?.content === "string" ? message.content : "";
    const completion = normalizeProviderCompletion(finishReason);
    const recoveryReason = resolveAgentRecoverableCompletion(completion);
    this.conversationMessages = [
      ...resolvedMessages,
      recoveryReason
        ? { role: "assistant", content: text }
        : buildNativeAssistantMessage({
            modelName: request.model,
            text,
            reasoningText,
            reasoningContentText,
            toolCalls,
          }),
    ];
    if (recoveryReason) {
      return {
        kind: "incomplete",
        reason: recoveryReason,
        providerReason: completion.providerReason,
        text,
        recoveryInstruction: buildAgentRecoveryInstruction(
          recoveryReason,
          "tool call",
        ),
        assistantMessage: {
          role: "assistant",
          content: text,
        },
      };
    }
    if (toolCalls.length) {
      return {
        kind: "tool_calls",
        calls: toolCalls,
        assistantMessage: {
          role: "assistant",
          content: text,
          tool_calls: toolCalls,
        },
      };
    }
    return {
      kind: "final",
      text,
      assistantMessage: {
        role: "assistant",
        content: text,
      },
    };
  }
}

export { OpenAIChatCompatAgentAdapter as OpenAICompatibleAgentAdapter };
