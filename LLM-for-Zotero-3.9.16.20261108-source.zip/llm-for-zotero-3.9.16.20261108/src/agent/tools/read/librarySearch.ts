import type { PaperContextRef } from "../../../shared/types";
import type { AgentToolDefinition, AgentToolGuidance } from "../../types";
import {
  type LibrarySortKey,
  type LibrarySortOrder,
  LibraryQueryService,
  type QueryLibraryEntity,
  type QueryLibraryFilters,
  type QueryLibraryInclude,
  type QueryLibraryMode,
} from "../../services/libraryQueryService";
import type {
  AgentSearchCondition,
  ZoteroGateway,
} from "../../services/zoteroGateway";
import {
  computeLibraryStatistics,
  STATISTICS_SECTIONS,
  type StatisticsSection,
} from "../../actions/libraryStatistics";
import {
  LIBRARY_SORT_KEYS,
  isLibrarySortKey,
} from "../../services/librarySortKeys";
import { fail, normalizePositiveInt, ok, validateObject } from "../shared";
import {
  SEARCH_CONDITION_SCHEMA,
  parseSearchCondition,
} from "../searchConditions";
import { readOnlyInvocationPlan } from "../../authorization/invocationPlan";
import { buildLibraryListModelView } from "../../services/libraryListModelView";
import { modelViewRoomTokens } from "./modelViewRoom";

type ToolGuidance = AgentToolGuidance;

/**
 * Library-level turns: a global (library) conversation, a selected
 * collection or tag scope, or no paper in scope at all.
 */
export function matchesLibraryLevelTurn(
  request: Parameters<ToolGuidance["matches"]>[0],
): boolean {
  const scope = request.turnPaperScope;
  if (!scope) return true;
  return (
    scope.conversationKind === "global" ||
    scope.collections.length > 0 ||
    scope.tags.length > 0 ||
    scope.papers.length === 0
  );
}

export const LIBRARY_SEARCH_GUIDANCE: ToolGuidance = {
  matches: matchesLibraryLevelTurn,
  instruction:
    "Use library_search to resolve named library targets; results never grant permission. If a name still matches several candidates, ask the user instead of guessing. For what the simple filters cannot express, pass conditions[] (Zotero advanced search); only filters:{deleted:true} lists trashed items.",
};

/**
 * Result-time rules for advanced searches, carried on a failed or empty
 * conditions[] search rather than on every library-level turn.
 */
export const LIBRARY_SEARCH_CONDITIONS_GUIDANCE =
  "Each conditions[] clause is {condition, operator, value}. Useful conditions: fulltextContent (the PDF text), abstractNote, DOI, ISBN, publisher, publicationTitle, dateAdded, dateModified, note, annotationText, citationKey, retracted, itemType, tag, collection. When an error lists the operators a condition accepts, retry with one of them rather than falling back to a plain text search. fulltextContent, annotationText and childNote match a child item (an attachment or a note), so pass resolveToParents:true or those matches are dropped and the search looks empty. joinMode:'all' is the default; use joinMode:'any' for an OR search (there are no grouping blocks).";

/** Result-time trash rule, carried on an empty item search of live items. */
export const LIBRARY_SEARCH_TRASH_GUIDANCE =
  "Trashed items are excluded from this search. To see the trash, repeat it with filters:{deleted:true}; that is the only way to enumerate trashed items, and it is what you need before calling library_delete with mode:'restore'.";

function withEmptySearchGuidance<T extends Record<string, unknown>>(
  payload: T,
  input: QueryLibraryInput,
): T | (T & { guidance: string }) {
  if (input.entity !== "items") return payload;
  if (!Array.isArray(payload.results) || payload.results.length > 0) {
    return payload;
  }
  const guidance = [
    input.conditions ? LIBRARY_SEARCH_CONDITIONS_GUIDANCE : "",
    input.filters?.deleted === true ? "" : LIBRARY_SEARCH_TRASH_GUIDANCE,
  ]
    .filter(Boolean)
    .join(" ");
  return guidance ? { ...payload, guidance } : payload;
}

type QueryLibraryInput = {
  entity: QueryLibraryEntity;
  mode: QueryLibraryMode;
  text?: string;
  refs?: Array<number | PaperContextRef>;
  filters?: QueryLibraryFilters;
  limit?: number;
  offset?: number;
  sort?: LibrarySortKey;
  order?: LibrarySortOrder;
  include?: QueryLibraryInclude[];
  view?: "flat" | "tree";
  sections?: StatisticsSection[];
  conditions?: AgentSearchCondition[];
  joinMode?: "all" | "any";
  resolveToParents?: boolean;
  libraryID?: number;
};

const QUERY_LIBRARY_SHAPE_HINT =
  "entity and mode are required. Examples: " +
  "{ entity:'items', mode:'search', text:'memory' }, " +
  "{ entity:'items', mode:'duplicates' }, " +
  "{ entity:'collections', mode:'list', view:'tree' }";

const VALID_INCLUDE = new Set<QueryLibraryInclude>([
  "metadata",
  "attachments",
  "tags",
  "collections",
  "abstract",
]);

function normalizeInclude(value: unknown): QueryLibraryInclude[] | undefined {
  if (!Array.isArray(value)) return undefined;
  const includes = value
    .map((entry) => (typeof entry === "string" ? entry.trim() : ""))
    .filter((entry): entry is QueryLibraryInclude =>
      VALID_INCLUDE.has(entry as QueryLibraryInclude),
    );
  return includes.length ? Array.from(new Set(includes)) : undefined;
}

/** undefined when absent; null when it names a section that does not exist. */
function normalizeStatisticsSections(
  value: unknown,
): StatisticsSection[] | undefined | null {
  if (!Array.isArray(value) || !value.length) return undefined;
  const names = value.map((entry) =>
    typeof entry === "string" ? entry.trim() : "",
  );
  if (
    names.some(
      (name) => !STATISTICS_SECTIONS.includes(name as StatisticsSection),
    )
  ) {
    return null;
  }
  return Array.from(new Set(names)) as StatisticsSection[];
}

function normalizeConditions(
  value: unknown,
): AgentSearchCondition[] | undefined {
  if (!Array.isArray(value)) return undefined;
  const conditions = value
    .map(parseSearchCondition)
    .filter((entry): entry is AgentSearchCondition => Boolean(entry));
  return conditions.length ? conditions : undefined;
}

function normalizeRef(value: unknown): number | PaperContextRef | null {
  if (typeof value === "number" && Number.isFinite(value) && value > 0) {
    return Math.floor(value);
  }
  if (!validateObject<Record<string, unknown>>(value)) return null;
  const itemId = normalizePositiveInt(value.itemId);
  const contextItemId = normalizePositiveInt(value.contextItemId);
  if (itemId && contextItemId) {
    return {
      itemId,
      contextItemId,
      title:
        typeof value.title === "string" && value.title.trim()
          ? value.title.trim()
          : `Paper ${itemId}`,
      attachmentTitle:
        typeof value.attachmentTitle === "string" &&
        value.attachmentTitle.trim()
          ? value.attachmentTitle.trim()
          : undefined,
      citationKey:
        typeof value.citationKey === "string" && value.citationKey.trim()
          ? value.citationKey.trim()
          : undefined,
      firstCreator:
        typeof value.firstCreator === "string" && value.firstCreator.trim()
          ? value.firstCreator.trim()
          : undefined,
      year:
        typeof value.year === "string" && value.year.trim()
          ? value.year.trim()
          : undefined,
    };
  }
  return itemId || null;
}

function normalizeRefs(
  value: unknown,
): Array<number | PaperContextRef> | undefined {
  if (!Array.isArray(value)) return undefined;
  const refs = value
    .map((entry) => normalizeRef(entry))
    .filter((entry): entry is number | PaperContextRef => Boolean(entry));
  return refs.length ? refs : undefined;
}

function normalizeFilters(value: unknown): QueryLibraryFilters | undefined {
  if (!validateObject<Record<string, unknown>>(value)) return undefined;
  const collectionId = normalizePositiveInt(value.collectionId);
  return {
    unfiled: value.unfiled === true || value.unfiled === "true",
    untagged: value.untagged === true || value.untagged === "true",
    hasPdf:
      value.hasPdf === true || value.hasPdf === false
        ? Boolean(value.hasPdf)
        : undefined,
    collectionId,
    author:
      typeof value.author === "string" && value.author.trim()
        ? value.author.trim()
        : undefined,
    yearFrom:
      typeof value.yearFrom === "number" && Number.isFinite(value.yearFrom)
        ? Math.floor(value.yearFrom)
        : undefined,
    yearTo:
      typeof value.yearTo === "number" && Number.isFinite(value.yearTo)
        ? Math.floor(value.yearTo)
        : undefined,
    itemType:
      typeof value.itemType === "string" && value.itemType.trim()
        ? value.itemType.trim()
        : undefined,
    tag:
      typeof value.tag === "string" && value.tag.trim()
        ? value.tag.trim()
        : undefined,
    deleted: value.deleted === true || value.deleted === "true",
  };
}

/**
 * What a statistics call carries that it would silently ignore: every filter
 * except collectionId, and text. A filter that is off (false, empty) is fine.
 */
function statisticsIgnoredInputs(args: Record<string, unknown>): string[] {
  const ignored: string[] = [];
  if (typeof args.text === "string" && args.text.trim()) ignored.push("text");
  const filters = normalizeFilters(args.filters);
  if (filters) {
    for (const [key, value] of Object.entries(filters)) {
      if (key === "collectionId") continue;
      const set = key === "hasPdf" ? value !== undefined : Boolean(value);
      if (set) ignored.push(`filters.${key}`);
    }
  }
  return ignored;
}

function normalizeLegacyQueryLibraryArgs(
  args: Record<string, unknown>,
): Record<string, unknown> {
  const normalized = { ...args };
  const query =
    typeof normalized.query === "string" && normalized.query.trim()
      ? normalized.query.trim()
      : "";
  const text =
    typeof normalized.text === "string" && normalized.text.trim()
      ? normalized.text.trim()
      : "";
  const topLevelCollectionId = normalizePositiveInt(normalized.collectionId);

  if (topLevelCollectionId) {
    const filters = validateObject<Record<string, unknown>>(normalized.filters)
      ? { ...normalized.filters }
      : {};
    if (!normalizePositiveInt(filters.collectionId)) {
      filters.collectionId = topLevelCollectionId;
    }
    normalized.filters = filters;
    delete normalized.collectionId;
    if (!normalized.entity && normalized.mode === "list") {
      normalized.entity = "items";
    }
  }

  if (!normalized.entity && !normalized.mode && query) {
    normalized.entity = "items";
    normalized.mode = "search";
    normalized.text = query;
  }
  if (normalized.mode === "query" && (query || text)) {
    if (!normalized.entity) normalized.entity = "items";
    normalized.mode = "search";
    normalized.text = text || query;
  }
  if (!normalized.entity && normalized.mode === "duplicates") {
    normalized.entity = "items";
  }
  if (
    normalized.entity === "collections" &&
    !normalized.mode &&
    normalized.view === "tree"
  ) {
    normalized.mode = "list";
  }
  if (!normalized.text && query && normalized.mode === "search") {
    normalized.text = query;
  }
  delete normalized.query;
  return normalized;
}

function resolveReferenceItemId(
  input: QueryLibraryInput,
  context: Parameters<
    AgentToolDefinition<QueryLibraryInput, unknown>["execute"]
  >[1],
  zoteroGateway: ZoteroGateway,
): number | null {
  const firstRef = input.refs?.[0];
  if (typeof firstRef === "number") return firstRef;
  if (firstRef && typeof firstRef === "object") return firstRef.itemId;
  const contextualPaper = zoteroGateway.listPaperContexts(context.request)[0];
  if (contextualPaper?.itemId) {
    return contextualPaper.itemId;
  }
  if (
    context.request.conversationKind === "global" ||
    context.request.turnPaperScope.collections.length ||
    context.request.turnPaperScope.tags.length
  ) {
    return null;
  }
  const activePaperContext = zoteroGateway.getActivePaperContext(
    context.item || zoteroGateway.getItem(context.request.activeItemId),
  );
  if (activePaperContext?.itemId) {
    return activePaperContext.itemId;
  }
  return normalizePositiveInt(context.request.activeItemId) || null;
}

function withResultCounts<T extends { results: unknown[] }>(
  payload: T,
  params: {
    totalCount?: number;
  } = {},
): T & { totalCount: number; returnedCount: number; limited: boolean } {
  const returnedCount = payload.results.length;
  const totalCount =
    Number.isFinite(params.totalCount) && Number(params.totalCount) >= 0
      ? Math.floor(Number(params.totalCount))
      : returnedCount;
  return {
    ...payload,
    totalCount,
    returnedCount,
    limited: totalCount > returnedCount,
  };
}

/**
 * Counts for a page taken at `offset`: `limited` and `nextOffset` say more
 * matches remain past this page, and are absent on the last one.
 */
function withPageCounts<T extends { results: unknown[] }>(
  payload: T,
  params: { totalCount: number; offset?: number },
): T & {
  totalCount: number;
  returnedCount: number;
  offset: number;
  nextOffset?: number;
  limited: boolean;
} {
  const returnedCount = payload.results.length;
  const totalCount = Math.max(0, Math.floor(params.totalCount));
  const offset = params.offset && params.offset > 0 ? params.offset : 0;
  const end = offset + returnedCount;
  return {
    ...payload,
    totalCount,
    returnedCount,
    offset,
    ...(end < totalCount ? { nextOffset: end } : {}),
    limited: end < totalCount,
  };
}

export function createLibrarySearchTool(
  zoteroGateway: ZoteroGateway,
): AgentToolDefinition<QueryLibraryInput, unknown> {
  const queryService = new LibraryQueryService(zoteroGateway);
  return {
    spec: {
      name: "library_search",
      description:
        "Discover, list, filter, and count Zotero items, collections, notes, tags, and libraries. Use this for finding library records; use library_read for detailed item state.",
      inputSchema: {
        type: "object",
        required: ["entity", "mode"],
        additionalProperties: false,
        properties: {
          entity: {
            type: "string",
            enum: [
              "items",
              "collections",
              "notes",
              "tags",
              "libraries",
              "itemTypes",
              "savedSearches",
              "statistics",
            ],
            description:
              "What to query: 'items' for any library item, 'collections' for folders, 'notes' to search/list notes (mode:'search' finds all notes including child notes, mode:'list' lists standalone notes only), 'tags' to list/search all tags in the library, 'libraries' to enumerate all libraries (personal + group), 'itemTypes' to discover Zotero's item types and the exact fields and creator types each one accepts (use this before creating an item or setting an unfamiliar field — a field the type does not have is rejected, not ignored), 'savedSearches' to list the library's saved searches and the conditions behind them, 'statistics' (mode:'list') for counts by type, year, author, journal, tag, collection and annotation over the library or filters.collectionId's direct members (subcollections not included); limit sets the length of top lists.",
          },
          mode: {
            type: "string",
            enum: ["search", "list", "related", "duplicates"],
          },
          text: { type: "string" },
          refs: {
            type: "array",
            items: {
              anyOf: [
                { type: "number" },
                {
                  type: "object",
                  additionalProperties: true,
                },
              ],
            },
          },
          filters: {
            type: "object",
            additionalProperties: false,
            properties: {
              unfiled: { type: "boolean" },
              untagged: { type: "boolean" },
              hasPdf: {
                type: "boolean",
                description:
                  "Set true to count/search PDF-backed paper-style items only; combine with itemType for narrower paper counts.",
              },
              collectionId: { type: "number" },
              author: {
                type: "string",
                description: "Filter by author name (substring match)",
              },
              yearFrom: {
                type: "number",
                description: "Include items from this year onward (inclusive)",
              },
              yearTo: {
                type: "number",
                description: "Include items up to this year (inclusive)",
              },
              itemType: {
                type: "string",
                description:
                  "Filter by Zotero item type, e.g. 'book', 'note', 'webpage', 'journalArticle', 'conferencePaper'. Only used with entity:'items'.",
              },
              tag: {
                type: "string",
                description:
                  "Filter by exact tag name (e.g. 'machine learning'). Only items with this tag are returned.",
              },
              deleted: {
                type: "boolean",
                description:
                  "Set true to list the trash instead of the library. Needed before restoring anything, since nothing else can enumerate what is in the trash.",
              },
            },
          },
          conditions: {
            type: "array",
            description:
              "Advanced search clauses, forwarded to Zotero's own search engine. Use this for anything the nine simple filters cannot express — fulltextContent, abstractNote, DOI, publisher, dateAdded, dateModified, note, annotationText, citationKey, retracted, publications, and every other Zotero search condition. Only valid with entity:'items'.",
            items: SEARCH_CONDITION_SCHEMA,
          },
          joinMode: {
            type: "string",
            enum: ["all", "any"],
            description:
              "Whether every condition must match ('all', the default) or any one of them ('any'). Applies to conditions[].",
          },
          resolveToParents: {
            type: "boolean",
            description:
              "Return the parent paper for matches that are child items. Required for conditions that match children — fulltextContent, annotationText and childNote match an attachment or note, and without this those matches are dropped and the search looks empty.",
          },
          libraryID: {
            type: "number",
            description:
              "Search a specific library. Defaults to the active one; a group library ID searches that group instead.",
          },
          view: {
            type: "string",
            enum: ["flat", "tree"],
            description:
              "For entity:'collections' mode:'list': 'flat' returns a list, 'tree' returns the full hierarchy with paper counts. Default: flat.",
          },
          limit: { type: "number" },
          offset: {
            type: "number",
            description:
              "Skip this many results before returning. Use with limit to page through a large result set across several calls; a capped result says limited:true with the true totalCount and the nextOffset to pass next. Applies to entity:'items' (mode:'list', mode:'search', mode:'duplicates' where it counts groups, and conditions[]), to entity:'notes' (mode:'list' and mode:'search'), and to entity:'tags'.",
          },
          sort: {
            type: "string",
            enum: [...LIBRARY_SORT_KEYS],
            description:
              "Order results before limit/offset are applied. Use sort:'dateAdded' for requests like 'the most recently added papers'; creator sorts by first author. Applies to entity:'items' with mode:'list'; text search returns relevance order and ignores this.",
          },
          order: {
            type: "string",
            enum: ["asc", "desc"],
            description:
              "Sort direction. Defaults to 'desc' for dates and year (newest first) and 'asc' for title and creator.",
          },
          include: {
            type: "array",
            items: {
              type: "string",
              enum: [
                "metadata",
                "attachments",
                "tags",
                "collections",
                "abstract",
              ],
            },
          },
          sections: {
            type: "array",
            items: { type: "string", enum: [...STATISTICS_SECTIONS] },
            description: "For entity:'statistics': which parts. Default: all.",
          },
        },
      },
      executionClass: "read",
      workCategory: "retrieval",
    },
    guidance: LIBRARY_SEARCH_GUIDANCE,
    presentation: {
      label: "Search Library",
      traceIcon: "library",
      summaries: {
        onCall: ({ args }) => {
          const entity =
            args && typeof args === "object"
              ? String((args as { entity?: unknown }).entity || "library")
              : "library";
          const mode =
            args && typeof args === "object"
              ? String((args as { mode?: unknown }).mode || "unspecified")
              : "unspecified";
          return `Querying ${entity} (${mode})`;
        },
        onSuccess: ({ content }) => {
          const treeCollections =
            content &&
            typeof content === "object" &&
            Array.isArray((content as { collections?: unknown[] }).collections)
              ? (content as { collections: unknown[] }).collections
              : [];
          const results =
            content &&
            typeof content === "object" &&
            Array.isArray((content as { results?: unknown[] }).results)
              ? (content as { results: unknown[] }).results
              : [];
          if (
            content &&
            typeof content === "object" &&
            (content as { entity?: unknown }).entity === "statistics"
          ) {
            return "Computed library statistics";
          }
          if (treeCollections.length > 0) {
            return `Loaded collection tree (${treeCollections.length} top-level folder${
              treeCollections.length === 1 ? "" : "s"
            })`;
          }
          const totalGroups = Number(
            content &&
              typeof content === "object" &&
              (content as { totalGroups?: unknown }).totalGroups
              ? (content as { totalGroups?: unknown }).totalGroups
              : 0,
          );
          if (totalGroups > 0) {
            return `Found ${totalGroups} duplicate group${
              totalGroups === 1 ? "" : "s"
            }`;
          }
          const totalCount = Number(
            content &&
              typeof content === "object" &&
              (content as { totalCount?: unknown }).totalCount
              ? (content as { totalCount?: unknown }).totalCount
              : results.length,
          );
          return totalCount > 0
            ? `Found ${totalCount} result${totalCount === 1 ? "" : "s"}${
                results.length < totalCount ? ` (${results.length} shown)` : ""
              }`
            : "No matching library results";
        },
      },
    },
    validate: (args) => {
      if (!validateObject<Record<string, unknown>>(args)) {
        return fail("Expected an object");
      }
      const normalizedArgs = normalizeLegacyQueryLibraryArgs(args);
      const entity =
        normalizedArgs.entity === "items" ||
        normalizedArgs.entity === "collections" ||
        normalizedArgs.entity === "notes" ||
        normalizedArgs.entity === "tags" ||
        normalizedArgs.entity === "libraries" ||
        normalizedArgs.entity === "itemTypes" ||
        normalizedArgs.entity === "savedSearches" ||
        normalizedArgs.entity === "statistics"
          ? (normalizedArgs.entity as QueryLibraryEntity)
          : null;
      const mode =
        normalizedArgs.mode === "search" ||
        normalizedArgs.mode === "list" ||
        normalizedArgs.mode === "related" ||
        normalizedArgs.mode === "duplicates"
          ? (normalizedArgs.mode as QueryLibraryMode)
          : null;
      if (!entity || !mode) {
        return fail(QUERY_LIBRARY_SHAPE_HINT);
      }
      if (entity === "collections" && !["search", "list"].includes(mode)) {
        return fail("collections only support mode:'search' or mode:'list'");
      }
      if (entity === "notes" && !["list", "search"].includes(mode)) {
        return fail("notes only support mode:'list' or mode:'search'");
      }
      if (entity === "tags" && !["list", "search"].includes(mode)) {
        return fail("tags only support mode:'list' or mode:'search'");
      }
      if (entity === "libraries" && mode !== "list") {
        return fail("libraries only support mode:'list'");
      }
      if (entity === "itemTypes" && !["list", "search"].includes(mode)) {
        return fail("itemTypes only support mode:'list' or mode:'search'");
      }
      if (entity === "savedSearches" && !["list", "search"].includes(mode)) {
        return fail("savedSearches only support mode:'list' or mode:'search'");
      }
      if (entity === "statistics" && mode !== "list") {
        return fail("statistics only supports mode:'list'");
      }
      const sections =
        entity === "statistics"
          ? normalizeStatisticsSections(normalizedArgs.sections)
          : undefined;
      if (sections === null) {
        return fail(
          `sections must be some of: ${STATISTICS_SECTIONS.join(", ")}`,
        );
      }
      if (entity === "statistics") {
        const ignored = statisticsIgnoredInputs(normalizedArgs);
        if (ignored.length) {
          return fail(
            `statistics counts the whole library or filters.collectionId's direct members; it cannot apply ${ignored.join(", ")}. Drop ${ignored.length === 1 ? "it" : "them"}, or list the items with entity:'items'.`,
          );
        }
      }
      const conditions = normalizeConditions(normalizedArgs.conditions);
      if (conditions && entity !== "items") {
        return fail(
          "conditions[] is only valid with entity:'items'. Collections, notes, tags and libraries are not searched through Zotero's condition engine.",
        );
      }
      if (conditions) {
        // hasPdf routes to a different engine entirely and untagged is a JS
        // filter applied after the fact, so neither can honour a condition
        // set. Silently ignoring one of them would return a confidently wrong
        // result. The other simple filters are honoured by intersection (see
        // ItemCapability.searchItemsByConditions).
        const filters = normalizedArgs.filters as
          | Record<string, unknown>
          | undefined;
        const conflicting = ["hasPdf", "untagged"].filter(
          (key) => filters?.[key] !== undefined,
        );
        if (conflicting.length) {
          return fail(
            `filters.${conflicting.join(" and filters.")} cannot be combined with conditions[], because ${conflicting.length === 1 ? "it is" : "they are"} applied outside Zotero's search engine. Express the same thing as a condition, or drop conditions[].`,
          );
        }
      }
      if (
        (entity === "items" || entity === "notes") &&
        mode === "search" &&
        !conditions
      ) {
        const text =
          typeof normalizedArgs.text === "string"
            ? normalizedArgs.text.trim()
            : "";
        if (!text) {
          return fail(
            "text is required for search mode. Use library_search({ entity:'items', mode:'search', text:'<terms>' }), or pass conditions[] for an advanced search. To list the items of a collection or tag, use mode:'list' with filters.",
          );
        }
      }
      if (mode === "related" && entity !== "items") {
        return fail("mode:'related' is only valid for entity:'items'");
      }
      const view =
        normalizedArgs.view === "tree"
          ? ("tree" as const)
          : normalizedArgs.view === "flat"
            ? ("flat" as const)
            : undefined;
      return ok<QueryLibraryInput>({
        entity,
        mode,
        conditions,
        joinMode:
          normalizedArgs.joinMode === "any" || normalizedArgs.joinMode === "all"
            ? normalizedArgs.joinMode
            : undefined,
        resolveToParents: normalizedArgs.resolveToParents === true,
        libraryID: normalizePositiveInt(normalizedArgs.libraryID),
        text:
          typeof normalizedArgs.text === "string" && normalizedArgs.text.trim()
            ? normalizedArgs.text.trim()
            : undefined,
        refs: normalizeRefs(normalizedArgs.refs),
        filters: normalizeFilters(normalizedArgs.filters),
        limit: normalizePositiveInt(normalizedArgs.limit),
        // offset is deliberately not normalizePositiveInt: 0 is a valid
        // starting offset and that helper rejects it.
        offset:
          Number.isFinite(normalizedArgs.offset) &&
          Number(normalizedArgs.offset) > 0
            ? Math.floor(Number(normalizedArgs.offset))
            : undefined,
        sort: isLibrarySortKey(normalizedArgs.sort)
          ? normalizedArgs.sort
          : undefined,
        // Pass the direction through verbatim. Collapsing anything that was
        // not "asc" to undefined made an explicit order:'desc' on a title
        // sort silently return A-Z.
        order:
          normalizedArgs.order === "asc" || normalizedArgs.order === "desc"
            ? normalizedArgs.order
            : undefined,
        include: normalizeInclude(normalizedArgs.include),
        sections,
        view,
      });
    },
    planInvocation: () =>
      readOnlyInvocationPlan({
        domains: ["zotero_library"],
        reason: "The structured library query reads Zotero records only.",
      }),
    // An item list shows every row briefly and the requested fields for the
    // top rows; the whole list stays behind a handle.
    buildModelView: (input, result, context) =>
      input.entity === "items" && input.mode === "list" && !input.conditions
        ? buildLibraryListModelView({
            input,
            result: result as never,
            roomTokens: modelViewRoomTokens(context.request),
          })
        : null,
    execute: async (input, context) => {
      if (input.entity === "itemTypes") {
        // Item-type definitions are global Zotero metadata, not library data.
        // Fields come back for a named type only. All ~35 types with their
        // full field lists is a large payload to spend on "what types exist".
        const result = zoteroGateway.listItemTypes({
          itemType: input.filters?.itemType || input.text,
        });
        return withResultCounts({
          entity: input.entity,
          mode: input.mode,
          results: result.itemTypes,
        });
      }
      if (input.entity === "libraries") {
        // Library enumeration is the bootstrap path for clients that do not
        // yet know which explicit libraryID to send.
        const results = zoteroGateway.listAllLibraries();
        return withResultCounts({
          entity: input.entity,
          mode: input.mode,
          results,
        });
      }
      const libraryID =
        input.libraryID ||
        zoteroGateway.resolveLibraryID({
          request: context.request,
          item: context.item,
        });
      if (!libraryID) {
        throw new Error("No active library available");
      }
      if (input.conditions) {
        let result: Awaited<
          ReturnType<ZoteroGateway["searchItemsByConditions"]>
        >;
        try {
          result = await zoteroGateway.searchItemsByConditions({
            libraryID,
            conditions: input.conditions,
            joinMode: input.joinMode,
            resolveToParents: input.resolveToParents,
            includeTrashed: input.filters?.deleted === true,
            filters: input.filters,
            limit: input.limit,
            offset: input.offset,
          });
        } catch (error) {
          const message =
            error instanceof Error ? error.message : String(error);
          throw new Error(
            `${message}\n\n${LIBRARY_SEARCH_CONDITIONS_GUIDANCE}`,
          );
        }
        return withEmptySearchGuidance(
          {
            entity: input.entity,
            mode: input.mode,
            results: result.items,
            totalCount: result.totalCount,
            returnedCount: result.returnedCount,
            offset: result.offset,
            // Present only when more remains, so its absence is a reliable
            // signal that the walk is finished.
            nextOffset: result.nextOffset,
            limited: result.nextOffset !== undefined,
            warnings: [],
          },
          input,
        );
      }
      if (input.entity === "statistics") {
        const collectionId = input.filters?.collectionId;
        const statistics = await computeLibraryStatistics({
          libraryID,
          zoteroGateway,
          scope: collectionId ? "collection" : "all",
          collectionId,
          sections: input.sections,
          topN: input.limit,
        });
        if (!statistics.ok) throw new Error(statistics.error);
        return {
          entity: input.entity,
          mode: input.mode,
          statistics: statistics.output,
        };
      }
      if (input.entity === "notes") {
        if (input.mode === "search") {
          const result = await queryService.searchNotes({
            libraryID,
            collectionId: input.filters?.collectionId,
            text: input.text || "",
            limit: input.limit,
            offset: input.offset,
          });
          return withPageCounts(
            {
              entity: input.entity,
              mode: input.mode,
              results: result.results,
              warnings: result.warnings,
            },
            { totalCount: result.totalCount, offset: input.offset },
          );
        }
        // list mode
        const result = await queryService.listStandaloneNotes({
          libraryID,
          collectionId: input.filters?.collectionId,
          limit: input.limit,
          offset: input.offset,
        });
        return withPageCounts(
          {
            entity: input.entity,
            mode: input.mode,
            results: result.results,
            warnings: result.warnings,
          },
          { totalCount: result.totalCount, offset: input.offset },
        );
      }
      if (input.entity === "savedSearches") {
        const results = zoteroGateway.listSavedSearches(libraryID);
        const query = (input.text || "").trim().toLowerCase();
        const filtered =
          input.mode === "search" && query
            ? results.filter((entry) =>
                entry.name.toLowerCase().includes(query),
              )
            : results;
        return withResultCounts({
          entity: input.entity,
          mode: input.mode,
          results: filtered,
        });
      }
      if (input.entity === "tags") {
        const result = await queryService.queryTags({
          libraryID,
          query: input.mode === "search" ? input.text : undefined,
          limit: input.limit,
          offset: input.offset,
          collectionId: input.filters?.collectionId,
        });
        return withPageCounts(
          {
            entity: input.entity,
            mode: input.mode,
            results: result.results,
            warnings: result.warnings,
          },
          { totalCount: result.totalCount, offset: input.offset },
        );
      }
      if (input.entity === "collections") {
        if (input.mode === "list" && input.view === "tree") {
          const tree = await queryService.browseCollectionTree({ libraryID });
          return {
            entity: input.entity,
            mode: input.mode,
            view: "tree",
            ...tree,
          };
        }
        const result = queryService.queryCollections({
          libraryID,
          mode: input.mode as "search" | "list",
          text: input.text,
          limit: input.limit,
        });
        return withResultCounts(
          {
            entity: input.entity,
            mode: input.mode,
            results: result.results,
            warnings: result.warnings,
          },
          { totalCount: result.totalCount },
        );
      }
      if (input.mode === "search") {
        const result = await queryService.searchItems({
          libraryID,
          text: input.text || "",
          filters: input.filters,
          limit: input.limit,
          offset: input.offset,
          include: input.include,
          excludeContextItemId:
            zoteroGateway.getActiveContextItem(context.item)?.id || null,
        });
        return withEmptySearchGuidance(
          withPageCounts(
            {
              entity: input.entity,
              mode: input.mode,
              results: result.results,
              warnings: result.warnings,
            },
            { totalCount: result.totalCount, offset: input.offset },
          ),
          input,
        );
      }
      if (input.mode === "list") {
        const result = await queryService.listItems({
          libraryID,
          filters: input.filters,
          limit: input.limit,
          offset: input.offset,
          sort: input.sort,
          order: input.order,
          include: input.include,
        });
        return withResultCounts(
          {
            entity: input.entity,
            mode: input.mode,
            totalCount: result.totalCount,
            results: result.results,
            warnings: result.warnings,
          },
          { totalCount: result.totalCount },
        );
      }
      if (input.mode === "related") {
        const referenceItemId = resolveReferenceItemId(
          input,
          context,
          zoteroGateway,
        );
        if (!referenceItemId) {
          throw new Error(
            "A reference paper is required for related-item queries",
          );
        }
        const result = await queryService.findRelatedItems({
          libraryID,
          referenceItemId,
          limit: input.limit,
          include: input.include,
        });
        return {
          entity: input.entity,
          mode: input.mode,
          referenceItemId,
          referenceTitle: result.referenceTitle,
          results: result.results,
          warnings: result.warnings,
        };
      }
      const result = await queryService.detectDuplicates({
        libraryID,
        limit: input.limit,
        offset: input.offset,
        include: input.include,
      });
      return withPageCounts(
        {
          entity: input.entity,
          mode: input.mode,
          totalGroups: result.totalGroups,
          results: result.results,
          warnings: result.warnings,
        },
        { totalCount: result.totalGroups, offset: input.offset },
      );
    },
  };
}
